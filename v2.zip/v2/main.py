def convert(line):
    return int(line, 2)

def get_reg(inst):
    arquivo = open("instruction.txt", "r")
    reg_1 = inst[4:7]
    reg_2 = inst[7:10]
    reg_3 = inst[10:13]

    return reg_1, reg_2, reg_3

def confirm_reg(register):
    arquivo = open("cache.txt", "r")
    regFile = arquivo.readlines()
    for tag in regFile:
        p = list(tag)
        y = p[0] + p [1] + p [2]
        if (y == register):
            x = tag.strip()
            arquivo.close()
            print("cache ",x)
            return x

    arquivo = open("registers.txt", "r")
    regFile = arquivo.readline()
    aux = []
    for m in range(8):
        aux.append(regFile[m*3 : (m+1)*3])

    for m in range(8):
        if (aux[m].strip() == register):
            novo = open('cache.txt', 'w')
            novo.seek(0)
            k = 0       #variavel auxiliar para adição
            l = 0       #variavel auxiliar para subtração
            for k in range (4):
                if((m + k) < (len(aux))):
                    novo.write(aux[m+k]+loadCache(convert(aux[m+k]))+'\n')
                else:
                    novo.write(aux[m-l]+loadCache(convert(aux[m-l]))+'\n')
                    l = l + 1
            novo.close()
            arquivo.close()
            confirm_reg(register)


def get_op(inst):
    return inst[:4]


def save(num, reg_3):
    aux = list(data)
    aux[convert(reg_3)] = str(num)
    aux2 = ''
    for i in range(len(aux)):
    	aux2 = aux2 + aux[i]
    dataFile.seek(0)
    dataFile.write(aux2)


def add(num_1, num_2):
    return int(num_1) + int(num_2)


def sub(num_1, num_2):
    return int(num_1) - int(num_2)


def execute(op, num_1, num_2, reg_3):
    if op == '0000':
        save(add(num_1, num_2), reg_3)
    elif op == '0001':
        save(sub(num_1, num_2), reg_3)

def loadCache(reg_1):
    arquivo = open("cache.txt", "r")
    regFile = arquivo.readlines()
    p = list(reg_1)
    reg_1 = p[0] + p [1] + p [2]
    for tag in regFile:
        p = list(tag)
        y = p[0] + p [1] + p [2]
        if(y == reg_1):
            return p[3]

def load(reg_1, reg_2):
    return data[reg_1], data[reg_2]



def get_inst(inst):
    op = get_op(inst)
    reg_1, reg_2, reg_3 = get_reg(inst)
    #print("pre reg: {} {} {}".format(reg_1, reg_2, reg_3))
    reg_1 = confirm_reg(reg_1)
    reg_2 = confirm_reg(reg_2)
    num_1 = loadCache(reg_1)
    num_2 = loadCache(reg_2)

    reg_3 = confirm_reg(reg_3)
    p = list(reg_3)
    reg_3 = p[0] + p [1] + p [2]
    #print("regs: {} {} {}".format(reg_1, reg_2, reg_3))

    #num_1, num_2 = load(convert(reg_1), convert(reg_2))
    execute(op, num_1, num_2, reg_3)
    print("show")


dataFile = open('data.txt', 'r+')
with open('instruction.txt') as instFile:
    for line in instFile.readlines():
        dataFile.seek(0)
        data = dataFile.readline()
        if(line != ' '):
            get_inst(line)
dataFile.close()
